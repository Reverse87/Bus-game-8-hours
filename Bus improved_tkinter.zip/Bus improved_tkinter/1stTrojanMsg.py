import tkinter
c_colt_fen = tkinter.Tk()
c_colt_fen.title('Enjoy your PC for its last minutes...')
c_colt_fen.geometry('1080x720')
c_colt_fen.minsize(999, 599)
c_colt_fen.maxsize(1920, 1080)
c_colt_fen.config(background='#333230')
c_colt_txt = tkinter.Label(text="Sadly, you downloaded a virus and now your PC is dead", fg='#FFFFFF', font=("Pusia", 25), bg='#333230')
c_colt_txt.pack()
c_colt_btn = tkinter.Button(text='Oh No', font=("Pusia", 30), bg='#F0F0F0', fg='#000000')
c_colt_btn.pack(padx=7, pady=5)
height = 720
width = 1080
c_colt_can = tkinter.Canvas(c_colt_fen, width=width, height=height, bg='#333230', bd=0, highlightthickness=0)
c_colt_can.pack()
c_colt_fen.mainloop()
