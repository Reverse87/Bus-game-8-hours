import random
import time
import tkinter
canvasWidth = 800
canvasHeight = 400
screen = tkinter.Tk()
screen.title('Bus game')
screen.geometry('800x400')
canvas = tkinter.Canvas(screen, width=canvasWidth, height=canvasHeight)
canvas.pack()
ground = tkinter.PhotoImage(file='ground.png')
canvas.create_image(canvasWidth/2, canvasHeight/2, image=ground)
path = tkinter.PhotoImage(file='path.png')
canvas.create_image(canvasWidth/2, canvasHeight/2, image=path)
bus = tkinter.PhotoImage(file='bus.png')
bus_anim = 200
canvas.create_image(canvasWidth/2, canvasHeight/2, image=bus)
openedWindow = True
score = 0
def mainloop():
    while openedWindow == True:
        move_bus()
        screen.update()
        time.sleep(1)
        if fenêtreOuverte == True:
            gameOver
leftKey = 0
rightKey = 0
def when_key_pressed(event):
    global leftKey, rightKey
    if event.keysym == "Left":
        leftKey = 1
    elif event.keysym == "Right":
        rightKey = 1
def when_key_unpressed(event):
    global leftKey, rightKey
    if event.keysym == "Left":
        leftKey = 0
    elif event.keysym == "Right":
        rightKey = 0
def score(event):
    global score
    global leftKey, rightKey
    score = score + 1
    if score == 1:
        print("1 m")
    elif score == 2:
        print("2 m")
    else:
        print(score, "m")
speedBus = 6
def move_bus():
    global score, leftKey, rightKey, speedBus
    mouvBus = speedBus*rightKey - speedBus*leftKey
    (busLeft, busRight) = canvas.coords(bus)
    if ((busLeft > 0 or mouvBus > 0) and (busRight < canvasWidth
    or mouvBus < 0)):
        canvas.move(bus, mouvBus, 0)
def close():
    global openedWindow
    openedWindow = False
    screen.destroy()
def gameOver():
    if bus_anim == 1000:
        openedWindow == False
        screen.destroy()
    elif bus_anim == 420:
        openedWindow == False
        screen.destroy()
screen.protocol("WM_DELETE_WINDOW", close)
screen.bind("<KeyPress>", when_key_pressed)
screen.bind("<KeyRelease>", when_key_unpressed)
screen.mainloop()
