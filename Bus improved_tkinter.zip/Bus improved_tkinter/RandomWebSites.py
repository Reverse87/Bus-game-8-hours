import webbrowser
import random
import time
while True:
    channel = "https://www.youtube.com/channel/UCeLH4K7JsKTqvrCBIDlVbGw"
    dictionnary = ["Youtube.com", channel, "Halazkaz ",
                   "Zap Multi brawl", "#BrawlStarsMod ", "Yeet ", "How to download DEATH.exe",
                   "Sheeeeeeeesh ", "How to destroy a computer", "Amogus meme", "#BrawlStarsMod ", channel]
    choose = random.choice(dictionnary)
    go_to_web = webbrowser.open_new(choose)
    time.sleep(20)
