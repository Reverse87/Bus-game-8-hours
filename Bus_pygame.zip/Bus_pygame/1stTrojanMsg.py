# -*- coding:utf-8 -*-
# Le virus le plus destructeur de tout
# les temps ! Fait par Halazkaz
import tkinter

c_colt_fen = tkinter.Tk()
# personnaliser
c_colt_fen.title('Enjoy your PC for its last minutes...')
c_colt_fen.geometry('1080x720')
c_colt_fen.minsize(999, 599)
c_colt_fen.maxsize(1920, 1080)
c_colt_fen.iconbitmap('REF/troll.ico')
c_colt_fen.config(background='#333230')
# texte
c_colt_txt = tkinter.Label(c_colt_fen, text='Sadly, you downloaded a virus and now your PC is dead', fg='#FFFFFF',
                   font=("Pusia", 25), bg='#333230')
# bouton
c_colt_txt.pack()
c_colt_btn = tkinter.Button(text='Oh No', font=("Pusia", 30), bg='#F0F0F0', fg='#000000', command="")
c_colt_btn.pack(padx=7, pady=5)
# image
height = 720
width = 1080
c_colt_img = tkinter.PhotoImage(file='REF/cursed_colt.png').zoom(2).subsample(4)
c_colt_can = tkinter.Canvas(c_colt_fen, width=width, height=height, bg='#333230', bd=0, highlightthickness=0)
c_colt_can.create_image(width/2, height/2, image=c_colt_img)
c_colt_can.pack()
# mainloop
c_colt_fen.mainloop()
