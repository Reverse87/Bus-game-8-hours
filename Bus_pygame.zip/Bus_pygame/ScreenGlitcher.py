import pygame
from sys import exit

pygame.init()
screen = pygame.display.set_mode((800, 400))
pygame.display.set_caption("Bus game")
eta = pygame.time.Clock()

test = pygame.image.load('bus.png')
test.fill('#eafb02')

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
    screen.blit(test, (200, 100))
    pygame.display.update()
    eta.tick(60)
