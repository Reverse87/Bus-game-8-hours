import tkinter

canvasWidth = 1440
canvasHeight = 720
screen = tkinter.Tk()
screen.title('Bus game')
screen.geometry('1440x720')
canvas = tkinter.Canvas(screen, width=canvasWidth, height=canvasHeight)
canvas.pack()
background_image = tkinter.PhotoImage(file='REF/bus/groundOG.png')
background = canvas.create_image(canvasWidth/2, canvasHeight/2, image=background_image)
lines_image = tkinter.PhotoImage(file='REF/bus/linesOG.png')
lines = canvas.create_image(canvasWidth/2, canvasHeight/2, image=lines_image)
bus_image = tkinter.PhotoImage(file='REF/bus/busOG.png')
bus_anim = 660
bus = canvas.create_image(bus_anim, 350, image=bus_image)
flag = 1
def game():
    if flag==1:
        mouve()
        gameOver()
        screen.update()
def mouve():
    global bus_anim
    canvas.coords(bus, bus_anim, 350)
    bus_anim -= 1

    if flag==1:
        canvas.after(20, mouve)
def close():
    global flag
    flag = 0
    screen.destroy()
def gameOver():
    global bus_anim
    if bus_anim == 1000:
        close()
    elif bus_anim == 420:
        close()
    else:
        flag=1
    
    canvas.after(50, gameOver)

    return
screen.protocol("WM_DELETE_WINDOW", close)
game()
